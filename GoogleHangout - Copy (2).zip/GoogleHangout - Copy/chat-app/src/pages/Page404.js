import React from "react";

const Page404 = () => {
  return <>404</>;
};


export default Page404;