import React from "react";
import ReactPhoneInput from "react-phone-input-material-ui";
import { TextField, withStyles } from "@material-ui/core";
import { Box, Stack } from "@mui/material";

import FormProvider from "../../components/hook-form/FormProvider";
import PhoneForm from "../../sections/settings/PhoneForm";

const styles = (theme) => ({
  field: {
    margin: "10px 0",
  },
  countryList: {
    ...theme.typography.body2,
  },
});

function PhoneField(props) {
  const { value, defaultCountry, onChange, classes } = props;

  return (
    <>
      <Box
        sx={{
          width: "100%",
          borderRadius: 2,
          backgroundColor: (theme) =>
            theme.palette.mode === "light"
              ? "#fff"
              : theme.palette.background.paper,
        }}
        p={1.5}
      >
        <FormProvider>
          <Stack alignItems={"center"} spacing={5} padding={4}>
            <Stack spacing={5} padding={4}>
              <ReactPhoneInput
                type="number"
                value={value}
                defaultCountry={defaultCountry || "ph"}
                onChange={onChange}
                inputClass={classes.field}
                dropdownClass={classes.countryList}
                component={TextField}
              />

              <PhoneForm />
            </Stack>
          </Stack>
        </FormProvider>
      </Box>
    </>
  );
}

export default withStyles(styles)(PhoneField);
