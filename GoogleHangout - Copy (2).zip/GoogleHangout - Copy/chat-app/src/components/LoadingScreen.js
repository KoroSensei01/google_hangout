import React from "react";

const LoadingScreen = () => {
  return <>Loading...</>;
};

export default LoadingScreen;
