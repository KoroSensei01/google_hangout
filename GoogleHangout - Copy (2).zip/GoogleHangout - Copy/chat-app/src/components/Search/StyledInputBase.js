import { InputBase } from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  padding: "4px 50px",
  width: "100%",
}));

export default StyledInputBase;
