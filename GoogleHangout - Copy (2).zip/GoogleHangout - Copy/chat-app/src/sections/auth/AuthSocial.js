import { Divider, IconButton, Stack } from "@mui/material";
import {
  FacebookLogo,
  GithubLogo,
  GoogleLogo,
  InstagramLogo,
  TwitterLogo,
} from "phosphor-react";
import React from "react";

const AuthSocial = () => {
  return (
    <div>
      <Divider
        sx={{
          my: 2.5,
          typography: "overline",
          color: "text.disabled",
          "&::before,:: after": {
            borderTopStyle: "dashed",
          },
        }}
      >
        OR
      </Divider>
      <Stack direction={"row"} justifyContent={"center"} spacing={2}>
        <IconButton>
          <GoogleLogo color="#DF3E30" />
        </IconButton>
        <IconButton color="inherit">
          <GithubLogo />
        </IconButton>
        <IconButton>
          <TwitterLogo color="#1c9cea" />
        </IconButton>
        <IconButton>
          <FacebookLogo color="#3b5998" />
        </IconButton>
        <IconButton>
          <InstagramLogo color=" #bc2a8d" />
        </IconButton>
      </Stack>
    </div>
  );
};

export default AuthSocial;
