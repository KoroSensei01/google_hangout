import React from "react";

import * as Yup from "yup";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import FormProvider from "../../components/hook-form/FormProvider";
import { Alert, Button, IconButton, Stack } from "@mui/material";
import { ControlComponent } from "../../components/hook-form";
import { useCallback } from "react";
import { Phone } from "phosphor-react";

const PhoneForm = () => {
  const LoginSchema = Yup.object().shape({
    sender: Yup.string().required("Name of the sender is required"),
    text: Yup.string().required("Text is required"),
    avatarUrl: Yup.string().required("Avatar is required").nullable(true),
  });

  const defaultValues = {
    name: "",
    about: "",
  };

  const methods = useForm({
    resolver: yupResolver(LoginSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    control,
    setValue,
    setError,
    handleSubmit,
    formState: { errors },
  } = methods;

  const values = watch();

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      const newFile = Object.assign(file, {
        preview: URL.createObjectURL(file),
      });

      if (file) {
        setValue("avatarUrl", newFile, { shouldValidate: true });
      }
    },
    [setValue]
  );

  const onSubmit = async (data) => {
    try {
      // Submit data
      console.log("Data", data);
    } catch (error) {
      console.log(error);
      reset();
      setError("afterSubmit", {
        ...error,
        message: error.message,
      });
    }
  };

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={3}>
        <Stack spacing={3}>
          {!!errors.afterSubmit && (
            <Alert severity="error">{errors.afterSubmit.message} </Alert>
          )}
          <ControlComponent
            name="sender"
            label="Sender"
            helperText={"Name is required"}
          />
          <ControlComponent
            multiline
            rows={3}
            maxRows={5}
            name="text"
            label="Text"
          />
        </Stack>
        <Stack direction={"row"} spacing={3} padding={2}>
          <Button
            color="primary"
            size="medium"
            type="submit"
            variant="outlined"
          >
            Send
          </Button>
        </Stack>
      </Stack>
    </FormProvider>
  );
};

export default PhoneForm;
